package com.example.First_Project.controller;

import java.lang.reflect.Method;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.First_Project.config.DbConfig;
import com.example.First_Project.config.MultiTenantConfig;

/**
 * REST API Controller for BOM Staging Data Viewer.
 *
 * Provides endpoints for:
 * - Environment/instance discovery (/environments)
 * - Database connection testing (/connect)
 * - Table listing (/table-names)
 * - Paginated table data (/table-data)
 * - Custom SQL execution (/query)
 *
 * All database endpoints require X-Instance header (e.g., "dev19__BOM").
 */
@RestController
@RequestMapping("/api/stgg2b")
public class EnvironmentController {

    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(EnvironmentController.class);

    @org.springframework.beans.factory.annotation.Autowired
    private MultiTenantConfig multiTenantConfig;

    @Value("${app.pagination.default-page-size:20}")
    private int defaultPageSize;

    @Value("${app.pagination.max-page-size:1000}")
    private int maxPageSize;

    // ==================== Environment Discovery ====================

    /**
     * GET /environments
     * Returns available environments and their instances.
     * No X-Instance header required.
     */
    @GetMapping("/environments")
    public Map<String, List<String>> getEnvironments() {
        return multiTenantConfig.getEnvironmentInstanceMap();
    }

    // ==================== Connection Testing ====================

    public static class ConnectRequest {
        private String environment;
        private String instance;

        public String getEnvironment() { return environment; }
        public void setEnvironment(String environment) { this.environment = environment; }
        public String getInstance() { return instance; }
        public void setInstance(String instance) { this.instance = instance; }
    }

    /**
     * POST /connect
     * Tests database connection for the selected environment/instance.
     * Requires X-Instance header.
     */
    @PostMapping("/connect")
    public Map<String, Object> connect(@RequestBody ConnectRequest request,
                                       @RequestHeader("X-Instance") String xInstance) {
        Map<String, Object> result = new LinkedHashMap<>();
        log.info("/connect called with environment={}, instance={}, X-Instance={}",
                request.getEnvironment(), request.getInstance(), xInstance);

        String instanceKey = request.getEnvironment() + "__" + request.getInstance();
        Map<String, DbConfig> dbInstanceMap = multiTenantConfig.getDbInstanceMap();
        log.info("Constructed instanceKey={}", instanceKey);
        log.info("dbInstanceMap keys loaded: {}", dbInstanceMap.keySet());
        if (!dbInstanceMap.containsKey(instanceKey)) {
            log.warn("Unknown instanceKey requested: {}. Available keys: {}",
                    instanceKey, dbInstanceMap.keySet());
            throw new IllegalArgumentException("Unknown instance: " + instanceKey);
        }

        DbConfig cfg = dbInstanceMap.get(instanceKey);
        log.info("DbConfig for instanceKey: {}", cfg);

        // Password empty check
        if (cfg.getPassword() == null || cfg.getPassword().trim().isEmpty()) {
            log.error("Connection failed for instanceKey={}, error=Database password is empty",
                    instanceKey);
            result.put("status", "failed");
            result.put("environment", request.getEnvironment());
            result.put("instance", request.getInstance());
            result.put("message",
                    "Connection failed: Ddatabase password is empty. Please provide a valid password.");
            return result;
        }

        try {
            log.info("Attempting to create DataSource for instanceKey={}", instanceKey);
            javax.sql.DataSource ds =multiTenantConfig.getOrCreateDataSource(instanceKey);
//                    MultiTenantConfig.createHikariDataSource(instanceKey, cfg);
            log.info("DataSource created successfully for instanceKey={}", instanceKey);
            JdbcTemplate localJdbcTemplate = new JdbcTemplate(ds);
            log.info("JdbcTemplate created, testing connection...");
            localJdbcTemplate.queryForObject("SELECT 'OK' FROM dual", String.class);
            log.info("Connection test succeeded for instanceKey={}", instanceKey);
            result.put("status", "connected");
            result.put("environment", request.getEnvironment());
            result.put("instance", request.getInstance());
            result.put("message", "Connection successful");
        } catch (RuntimeException e) {
            log.error("Connection failed for instanceKey={}, error={}",
                    instanceKey, e.getMessage(), e);
            result.put("status", "failed");
            result.put("environment", request.getEnvironment());
            result.put("instance", request.getInstance());
            result.put("message", "Connection failed: " + e.getMessage());
        }

        return result;
    }

    // ==================== Table Operations ====================

    /**
     * GET /table-names
     * Returns list of tables in the current schema.
     * Requires X-Instance header.
     */
    @GetMapping("/table-names")
    public Map<Integer, String> getTableNames(@RequestHeader("X-Instance") String xInstance) {
        String sql = "SELECT table_name FROM user_tables ORDER BY table_name";
        Map<String, DbConfig> dbInstanceMap = multiTenantConfig.getDbInstanceMap();
        Map<Integer, String> result = new LinkedHashMap<>();

        if (!dbInstanceMap.containsKey(xInstance)) {
            result.put(-1, "Unknown instance: " + xInstance);
            return result;
        }

        DbConfig cfg = dbInstanceMap.get(xInstance);
        // Password empty check
        if (cfg.getPassword() == null || cfg.getPassword().trim().isEmpty()) {
            result.put(-1, "Database password is empty. Please provide a valid password.");
            return result;
        }

        try {
            javax.sql.DataSource ds =multiTenantConfig.getOrCreateDataSource(xInstance);
//                    MultiTenantConfig.createHikariDataSource(xInstance, cfg);
            JdbcTemplate localJdbcTemplate = new JdbcTemplate(ds);

            return localJdbcTemplate.execute(sql, (PreparedStatement ps) -> {
                Map<Integer, String> tableResult = new LinkedHashMap<>();
                try (ResultSet rs = ps.executeQuery()) {
                    int index = 1;
                    while (rs.next()) {
                        String tableName = rs.getString("TABLE_NAME");
                        tableResult.put(index, tableName);
                        index++;
                    }
                } catch (SQLException e) {
                    tableResult.put(-1, "Error querying table names: " + e.getMessage());
                }
                return tableResult;
            });
        } catch (Exception e) {
            result.put(-1, "Error: " + e.getMessage());
            return result;
        }
    }

    /**
     * GET /table-data?table=X&page=1&size=20
     * Returns paginated table data with total row count.
     * Requires X-Instance header.
     */
    @GetMapping("/table-data")
    public Map<String, Object> getTableData(@RequestHeader("X-Instance") String xInstance,
                                            @RequestParam(name = "table") String tableName,
                                            @RequestParam(defaultValue = "1") int page,
                                            @RequestParam(defaultValue = "20") int size) {

        if (page < 1) page = 1;
        if (size < 1) size = defaultPageSize;
        if (size > maxPageSize) size = maxPageSize;

        int offset = (page - 1) * size;

        Map<String, DbConfig> dbInstanceMap = multiTenantConfig.getDbInstanceMap();
        if (!dbInstanceMap.containsKey(xInstance)) {
            throw new IllegalArgumentException("Unknown instance: " + xInstance);
        }
        DbConfig cfg = dbInstanceMap.get(xInstance);
        javax.sql.DataSource ds = multiTenantConfig.getOrCreateDataSource(xInstance);
//        MultiTenantConfig.createHikariDataSource(xInstance, cfg);
        JdbcTemplate localJdbcTemplate = new JdbcTemplate(ds);

        String countSql = "SELECT COUNT(*) FROM " + tableName;
        Long totalRows = localJdbcTemplate.queryForObject(countSql, Long.class);
        if (totalRows == null) totalRows = 0L;

        String dataSql = "SELECT * FROM " + tableName + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

        final int finalPage = page;
        final int finalSize = size;
        final long finalTotalRows = totalRows;

        return localJdbcTemplate.execute(dataSql, (PreparedStatement ps) -> {
            ps.setInt(1, offset);
            ps.setInt(2, finalSize);

            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int columnCount = md.getColumnCount();

                List<String> columns = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    columns.add(md.getColumnLabel(i));
                }

                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        String colName = md.getColumnLabel(i);
                        Object raw = rs.getObject(i);
                        Object value = raw;

                        // Normalize JDBC / Oracle types

                        if (value instanceof Clob clob) {
                            value = clob.getSubString(1, (int) clob.length());
                        } else if (value instanceof Timestamp ts) {
                            value = ts.toInstant().toString();
                        } else if (value != null
                                && "oracle.sql.TIMESTAMP".equals(value.getClass().getName())) {
                            try {
                                Method m = value.getClass().getMethod("timestampValue");
                                Timestamp ts = (Timestamp) m.invoke(value);
                                value = ts.toInstant().toString();
                            } catch (ReflectiveOperationException ex) {
                                value = value.toString();
                            }
                        }

                        row.put(colName, value);
                    }
                    rows.add(row);
                }

                Map<String, Object> result = new LinkedHashMap<>();
                result.put("columns", columns);
                result.put("rows", rows);
                result.put("totalRows", finalTotalRows);
                result.put("page", finalPage);
                result.put("pageSize", finalSize);
                return result;
            } catch (SQLException e) {
                throw new RuntimeException("Error querying table " + tableName, e);
            }
        });
    }

    // ==================== Custom SQL Execution ====================

    public static class QueryRequest {
        private String sql;
        private Integer page; // optional
        private Integer size; // optional

        public String getSql() { return sql; }
        public void setSql(String sql) { this.sql = sql; }

        public Integer getPage() { return page; }
        public void setPage(Integer page) { this.page = page; }

        public Integer getSize() { return size; }
        public void setSize(Integer size) { this.size = size; }
    }

    /**
     * POST /query
     * Executes custom SQL (SELECT, INSERT, UPDATE, DELETE).
     * SELECT queries are capped at 1000 rows.
     * Requires X-Instance header.
     */
//    @PostMapping("/query")
//    public Map<String, Object> executeQuery(@RequestHeader("X-Instance") String xInstance,
//                                            @RequestBody QueryRequest request) {
//        if (request == null || request.getSql() == null || request.getSql().trim().isEmpty()) {
//            throw new IllegalArgumentException("SQL must not be empty");
//        }
//
//        Map<String, DbConfig> dbInstanceMap = multiTenantConfig.getDbInstanceMap();
//        if (!dbInstanceMap.containsKey(xInstance)) {
//            throw new IllegalArgumentException("Unknown instance: " + xInstance);
//        }
//        DbConfig cfg = dbInstanceMap.get(xInstance);
//        javax.sql.DataSource ds = multiTenantConfig.getOrCreateDataSource(xInstance);
////        MultiTenantConfig.createHikariDataSource(xInstance, cfg);
//        JdbcTemplate localJdbcTemplate = new JdbcTemplate(ds);
//
//        String sql = request.getSql().trim().replaceAll(";+$", "").trim();
//        String upper = sql.toUpperCase(Locale.ROOT);
//        boolean isSelect = upper.startsWith("SELECT");
//
////        if (isSelect && !upper.contains("FETCH FIRST") && !upper.contains("ROWNUM")) {
////            sql = sql + " FETCH FIRST 1000 ROWS ONLY";
////        }
//
//        if (isSelect) {
//            String finalSql = sql;
//            return localJdbcTemplate.execute(finalSql, (PreparedStatement ps) -> {
//                try (ResultSet rs = ps.executeQuery()) {
//                    ResultSetMetaData md = rs.getMetaData();
//                    int columnCount = md.getColumnCount();
//
//                    List<String> columns = new ArrayList<>();
//                    for (int i = 1; i <= columnCount; i++) {
//                        columns.add(md.getColumnLabel(i));
//                    }
//
//                    List<Map<String, Object>> rows = new ArrayList<>();
//                    while (rs.next()) {
//                        Map<String, Object> row = new LinkedHashMap<>();
//                        for (int i = 1; i <= columnCount; i++) {
//                            String colName = md.getColumnLabel(i);
//                            Object raw = rs.getObject(i);
//                            Object value = raw;
//
//                            if (value instanceof Clob clob) {
//                                value = clob.getSubString(1, (int) clob.length());
//                            } else if (value instanceof Timestamp ts) {
//                                value = ts.toInstant().toString();
//                            } else if (value != null
//                                    && "oracle.sql.TIMESTAMP".equals(value.getClass().getName())) {
//                                try {
//                                    Method m = value.getClass().getMethod("timestampValue");
//                                    Timestamp ts = (Timestamp) m.invoke(value);
//                                    value = ts.toInstant().toString();
//                                } catch (ReflectiveOperationException ex) {
//                                    value = value.toString();
//                                }
//                            }
//
//                            row.put(colName, value);
//                        }
//                        rows.add(row);
//                    }
//
//                    Map<String, Object> res = new LinkedHashMap<>();
//                    res.put("type", "SELECT");
//                    res.put("columns", columns);
//                    res.put("rows", rows);
//                    return res;
//                } catch (SQLException e) {
//                    throw new RuntimeException("Error executing SELECT: " + e.getMessage(), e);
//                }
//            });
//        } else {
//            int rowsAffected = localJdbcTemplate.update(sql);
//            Map<String, Object> result = new LinkedHashMap<>();
//            result.put("type", upper.split("\\s+")[0]);
//            result.put("rowsAffected", rowsAffected);
//            result.put("message", "Query executed successfully");
//            return result;
//        }
//    }
    @PostMapping("/query")
    public Map<String, Object> executeQuery(@RequestHeader("X-Instance") String xInstance,
                                            @RequestBody QueryRequest request) {
        if (request == null || request.getSql() == null || request.getSql().trim().isEmpty()) {
            throw new IllegalArgumentException("SQL must not be empty");
        }

        Map<String, DbConfig> dbInstanceMap = multiTenantConfig.getDbInstanceMap();
        if (!dbInstanceMap.containsKey(xInstance)) {
            throw new IllegalArgumentException("Unknown instance: " + xInstance);
        }

        DbConfig cfg = dbInstanceMap.get(xInstance);
        javax.sql.DataSource ds = multiTenantConfig.getOrCreateDataSource(xInstance);
        JdbcTemplate localJdbcTemplate = new JdbcTemplate(ds);

        String originalSql = request.getSql().trim().replaceAll(";+$", "").trim();
        String upper = originalSql.toUpperCase(Locale.ROOT);
        boolean isSelect = upper.startsWith("SELECT");

        if (!isSelect) {
            // Non-SELECT: keep same behaviour as before
            int rowsAffected = localJdbcTemplate.update(originalSql);
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("type", upper.split("\\s+")[0]);
            result.put("rowsAffected", rowsAffected);
            result.put("message", "Query executed successfully");
            return result;
        }

        // --------- SELECT with pagination (similar to /table-data) ---------

        // 1) Normalize page & size using same logic as /table-data
        int page = (request.getPage() == null) ? 1 : request.getPage();
        int size = (request.getSize() == null) ? defaultPageSize : request.getSize();

        if (page < 1) page = 1;
        if (size < 1) size = defaultPageSize;
        if (size > maxPageSize) size = maxPageSize;

        int offset = (page - 1) * size;

        // 2) Build count SQL: SELECT COUNT(*) FROM ( originalSql ) t
        String countSql = "SELECT COUNT(*) FROM (" + originalSql + ") t";

        Long totalRows = localJdbcTemplate.queryForObject(countSql, Long.class);
        if (totalRows == null) totalRows = 0L;

        // 3) Build paginated SQL: SELECT * FROM ( originalSql ) t OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
        String paginatedSql =
                "SELECT * FROM (" + originalSql + ") t OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

        final int finalPage = page;
        final int finalSize = size;
        final long finalTotalRows = totalRows;

        return localJdbcTemplate.execute(paginatedSql, (PreparedStatement ps) -> {
            ps.setInt(1, offset);
            ps.setInt(2, finalSize);

            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int columnCount = md.getColumnCount();

                List<String> columns = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    columns.add(md.getColumnLabel(i));
                }

                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        String colName = md.getColumnLabel(i);
                        Object raw = rs.getObject(i);
                        Object value = raw;

                        // Same normalization logic you already use
                        if (value instanceof Clob clob) {
                            value = clob.getSubString(1, (int) clob.length());
                        } else if (value instanceof Timestamp ts) {
                            value = ts.toInstant().toString();
                        } else if (value != null
                                && "oracle.sql.TIMESTAMP".equals(value.getClass().getName())) {
                            try {
                                Method m = value.getClass().getMethod("timestampValue");
                                Timestamp ts = (Timestamp) m.invoke(value);
                                value = ts.toInstant().toString();
                            } catch (ReflectiveOperationException ex) {
                                value = value.toString();
                            }
                        }

                        row.put(colName, value);
                    }
                    rows.add(row);
                }

                Map<String, Object> res = new LinkedHashMap<>();
                res.put("type", "SELECT");
                res.put("columns", columns);
                res.put("rows", rows);
                res.put("totalRows", finalTotalRows);
                res.put("page", finalPage);
                res.put("pageSize", finalSize);
                return res;
            } catch (SQLException e) {
                throw new RuntimeException("Error executing SELECT: " + e.getMessage(), e);
            }
        });
    }

    // ==================== Health Check ====================

    /**
     * GET /test
     * Simple health check endpoint.
     * No X-Instance header required.
     */
    @GetMapping("/test")
    public String test() {
        return "OK";
    }
}