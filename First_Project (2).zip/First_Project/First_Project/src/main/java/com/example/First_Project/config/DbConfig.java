package com.example.First_Project.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Model representing a single database instance entry in db-mapping.json.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DbConfig {

    private String host;
    private int port;
    private String sid;
    private String username;
    private String password;
    private String displayName;
    private boolean hasPassword;
    // ---- Getters & Setters ----

    public String getHost() { return host; }
    public void setHost(String host) { this.host = host; }

    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }

    public String getSid() { return sid; }
    public void setSid(String sid) { this.sid = sid; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public boolean isHasPassword() { return hasPassword; }
    public void setHasPassword(boolean hasPassword) { this.hasPassword = hasPassword; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    /** Build the Oracle JDBC thin URL using service-name style. */
    public String toJdbcUrl() {
        // 'sid' field actually holds the service name (e.g., "plmmed30")
        return String.format("jdbc:oracle:thin:@//%s:%d/%s", host, port, sid);
    }
}
