package com.example.First_Project.config;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;

/**
 * Multi-tenant database configuration.
 *
 * Reads db-mapping.json at startup, loads DbConfig per instance,
 * and lazily creates a HikariCP DataSource per instance key.
 *
 * Configuration properties:
 * - app.db-mapping.path: Path to db-mapping.json (default: classpath:db-mapping.json)
 */
@Configuration
public class MultiTenantConfig {

    private static final Logger log = LoggerFactory.getLogger(MultiTenantConfig.class);

    private final String dbMappingPath;
    private final ResourceLoader resourceLoader;

    /**
     * Map of instanceKey (env__instanceName) → DbConfig loaded from db-mapping.json.
     */
    private final Map<String, DbConfig> instanceMap;

    /**
     * Map of instanceKey → DataSource (created lazily).
     */
    private final Map<String, DataSource> dataSourceMap = new LinkedHashMap<>();

    /**
     * Map of environment name → list of instance display names.
     */
    private Map<String, List<String>> environmentMap;

    @org.springframework.beans.factory.annotation.Autowired
    public MultiTenantConfig(ResourceLoader resourceLoader,
                             @Value("${app.db-mapping.path:classpath:db-mapping.json}") String dbMappingPath) {
        this.resourceLoader = resourceLoader;
        this.dbMappingPath = dbMappingPath;
        this.instanceMap = loadDbMapping();   // load configs at startup
    }

    // ───────── Beans exposed to controllers ─────────

    @Bean
    public Map<String, List<String>> environmentInstanceMap() {
        return getEnvironmentInstanceMap();
    }

    @Bean
    public Map<String, DbConfig> dbInstanceMap() {
        log.info("MultiTenantConfig: dbInstanceMap bean keys = {}", instanceMap.keySet());
        return getDbInstanceMap();
    }

    public Map<String, DbConfig> getDbInstanceMap() {
        return instanceMap;
    }

    public Map<String, List<String>> getEnvironmentInstanceMap() {
        return environmentMap;
    }

    public Map<String, DataSource> getDataSourceMap() {
        return dataSourceMap;
    }

    /**
     * Lazily get or create a DataSource for the given instance key.
     * If a pool already exists, reuse it; otherwise, create and cache a new one.
     */
    public synchronized DataSource getOrCreateDataSource(String instanceKey) {
        if (dataSourceMap.containsKey(instanceKey)) {
            return dataSourceMap.get(instanceKey);  // reuse
        }

        DbConfig cfg = instanceMap.get(instanceKey);
        if (cfg == null) {
            throw new IllegalArgumentException("Unknown instance: " + instanceKey);
        }

        HikariDataSource ds = new HikariDataSource();
        ds.setPoolName("HikariPool-" + instanceKey);
        ds.setJdbcUrl(cfg.toJdbcUrl());
        ds.setUsername(cfg.getUsername());
        ds.setPassword(cfg.getPassword());
        ds.setDriverClassName("oracle.jdbc.OracleDriver");
        ds.setMaximumPoolSize(45);
        ds.setMinimumIdle(0);
        ds.setIdleTimeout(300_000);
        ds.setConnectionTimeout(30_000);
        ds.setMaxLifetime(1_800_000);
        ds.setConnectionTestQuery("SELECT 1 FROM dual");
        ds.setInitializationFailTimeout(-1);

        dataSourceMap.put(instanceKey, ds);
        log.info("Created HikariCP DataSource for instance: {}", instanceKey);
        log.info("Total DataSources in cache: {}", dataSourceMap.size());

        return ds;
    }

    // ───────── Mapping loader ─────────

    private Map<String, DbConfig> loadDbMapping() {
        Map<String, DbConfig> result = new LinkedHashMap<>();
        environmentMap = new LinkedHashMap<>();

        log.info("Loading database mapping from: {}", dbMappingPath);
        if (dbMappingPath == null || dbMappingPath.trim().isEmpty()) {
            log.error("dbMappingPath is null or empty! Check application.properties and injection.");
        }

        try {
            Resource resource = resourceLoader.getResource(dbMappingPath);
            log.info("ResourceLoader resolved db-mapping.json: {}", resource);
            try (InputStream is = resource.getInputStream()) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(is);
                JsonNode envNode = root.get("environment");

                if (envNode == null) {
                    log.error("db-mapping.json missing 'environment' key!");
                    throw new RuntimeException("db-mapping.json missing 'environment' key");
                }

                Iterator<String> envNames = envNode.fieldNames();
                while (envNames.hasNext()) {
                    String envName = envNames.next();
                    JsonNode envConfig = envNode.get(envName);
                    JsonNode instancesNode = envConfig.get("instances");

                    if (instancesNode == null) {
                        log.warn("Environment '{}' has no 'instances' key, skipping", envName);
                        continue;
                    }

                    List<String> instanceNames = new ArrayList<>();
                    Iterator<String> instNames = instancesNode.fieldNames();
                    while (instNames.hasNext()) {
                        String instName = instNames.next();
                        JsonNode instConfig = instancesNode.get(instName);
                        try {
                            DbConfig cfg = mapper.treeToValue(instConfig, DbConfig.class);
                            cfg.setDisplayName(instName);

                            // ── compute and set hasPassword here ──
                            boolean hasPassword = cfg.getPassword() != null &&
                                    !cfg.getPassword().trim().isEmpty();
                            cfg.setHasPassword(hasPassword);
                            log.info("Instance '{}' in environment '{}' hasPassword = {}",
                                    instName, envName, cfg.isHasPassword());
                            if (!hasPassword) {
                                log.error("Password is null/empty for instance '{}' in environment '{}'",
                                        instName, envName);
                                // You can decide to:
                                //  - still add it (so frontend can still see instance)
                                //  - or skip it: continue;
                            }
                            // ──────────────────────────────────────

                            String key = envName + "__" + instName;
                            result.put(key, cfg);
                            instanceNames.add(instName);
                            log.info("Loaded instance: {} for environment: {}", instName, envName);
                            log.info("DbConfig loaded: {}", cfg);
                        }  catch (com.fasterxml.jackson.core.JsonProcessingException e) {
                            log.error("Failed to parse DbConfig for instance {} in environment {}",
                                    instName, envName, e);
                        }
                    }
                    environmentMap.put(envName, instanceNames);
                    log.info("Environment '{}' loaded with instances: {}", envName, instanceNames);
                }
            }
        } catch (java.io.IOException e) {
            log.error("Failed to load db-mapping from: {}", dbMappingPath, e);
            throw new RuntimeException("Failed to load db-mapping from: " + dbMappingPath, e);
        }

        log.info("Loaded {} environments with {} total instances",
                environmentMap.size(), result.size());
        return result;
    }
}