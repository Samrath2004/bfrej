package com.example.First_Project.config;

import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet filter that reads the {@code X-Instance} HTTP header,
 * validates it against the known instances, sets it in
 * {@link DatabaseContextHolder}, and clears it after the request.
 *
 * Endpoints that don't need a DB (like /test or /config) are skipped.
 */
@Component
@Order(1)
public class InstanceFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(InstanceFilter.class);
    private static final String HEADER = "X-Instance";

    private final Map<String, DbConfig> dbInstanceMap;

    public InstanceFilter(@org.springframework.beans.factory.annotation.Qualifier("dbInstanceMap") Map<String, DbConfig> dbInstanceMap) {
        this.dbInstanceMap = dbInstanceMap;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        String path = req.getRequestURI();

        // Skip CORS preflight OPTIONS requests
        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) {
            chain.doFilter(request, response);
            return;
        }

        // Skip filter for endpoints that don't touch the database
        if (path.endsWith("/environments") 
                || path.endsWith("/test") || path.endsWith("/config")
                || path.startsWith("/actuator")) {
            chain.doFilter(request, response);
            return;
        }

        // Check if this is a DB-accessing endpoint under /api/stgg2b
        boolean needsDbAccess = path.startsWith("/api/stgg2b") 
                && !path.endsWith("/environments");

        if (!needsDbAccess) {
            chain.doFilter(request, response);
            return;
        }

        String instance = req.getHeader(HEADER);
        log.info("InstanceFilter: Received X-Instance header: '{}', all available keys: {}", instance, dbInstanceMap.keySet());

        if (instance == null || instance.isBlank()) {
            log.warn("InstanceFilter: Missing or blank X-Instance header");
            sendError(response, "Missing or invalid X-Instance header");
            return;
        }

        // Validate format: must be "envName__dbUsername"
        if (!instance.contains("__")) {
            log.warn("InstanceFilter: X-Instance header does not contain '__': '{}'", instance);
            sendError(response, "Missing or invalid X-Instance header");
            return;
        }

        if (!dbInstanceMap.containsKey(instance)) {
            log.warn("InstanceFilter: Unknown instance requested: '{}'. Available keys: {}", instance, dbInstanceMap.keySet());
            sendError(response, "Missing or invalid X-Instance header");
            return;
        }

        // Get DB config for logging
        DbConfig cfg = dbInstanceMap.get(instance);

        try {
            DatabaseContextHolder.set(instance);
            
            // Log connection details
            log.info("=== DB CONNECTION REQUEST ===");
            log.info("Instance Key: {}", instance);
            log.info("JDBC URL: {}", cfg.toJdbcUrl());
            log.info("Username: {}", cfg.getUsername());
            log.info("Password: {}", cfg.getPassword());
            log.info("Request Path: {} {}", req.getMethod(), path);
            log.info("==============================");
            
            chain.doFilter(request, response);
        } finally {
            DatabaseContextHolder.clear();
        }
    }

    private void sendError(ServletResponse response, String message) throws IOException {
        ((HttpServletResponse) response).setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\":\"" + message + "\"}");
    }
}
