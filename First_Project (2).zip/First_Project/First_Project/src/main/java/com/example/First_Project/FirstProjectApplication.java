package com.example.First_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * BOM Staging Data Viewer - Spring Boot Application
 *
 * Multi-tenant Oracle database browser with dynamic routing.
 * Supports multiple environments (dev19, dev07, dev03, etc.) and
 * multiple database instances per environment.
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class FirstProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstProjectApplication.class, args);
	}

}
