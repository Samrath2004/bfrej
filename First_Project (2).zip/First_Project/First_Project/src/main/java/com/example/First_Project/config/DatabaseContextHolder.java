package com.example.First_Project.config;

/**
 * ThreadLocal holder that stores the current database instance key
 * (e.g. "dev7_PLM_MEDIATOR_ADMIN") for the lifetime of one HTTP request.
 *
 * Set by {@link InstanceFilter}, read by {@link DynamicRoutingDataSource},
 * cleared after the request completes.
 */
public class DatabaseContextHolder {

    private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();

    public static void set(String instanceKey) {
        CONTEXT.set(instanceKey);
    }

    public static String get() {
        return CONTEXT.get();
    }

    public static void clear() {
        CONTEXT.remove();
    }
}
