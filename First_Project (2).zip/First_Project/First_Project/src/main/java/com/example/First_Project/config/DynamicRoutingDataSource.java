package com.example.First_Project.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * A routing DataSource that delegates to one of the pre-created
 * target DataSources based on the value stored in {@link DatabaseContextHolder}.
 */
public class DynamicRoutingDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        return DatabaseContextHolder.get();
    }
}
